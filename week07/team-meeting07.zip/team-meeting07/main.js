import Hikes from './hikes.js';

var hikes = new Hikes('hikes');
hikes.showHikeList();
